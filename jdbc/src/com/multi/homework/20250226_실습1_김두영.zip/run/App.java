package com.multi.homework.board_prj.run;

import com.multi.homework.board_prj.view.BoardMenu;

public class App {
    public static void main(String[] args) {
        new BoardMenu().mainMenu();
    }
}
